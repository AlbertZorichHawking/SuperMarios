# How To Start Game

run `main.py`

# How to Play



- use LEFT/RIGHT/DOWN key to control player
- use key 'a' to jump
- use key 's' to shoot firewall or run

# Requirement



- Python 3..12
- Python-Pygame 2.6.1

You can run this line in your shell

```shell
pip install pygame
```

